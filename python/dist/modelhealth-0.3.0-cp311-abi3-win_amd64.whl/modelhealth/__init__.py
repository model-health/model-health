"""Model Health Python SDK.

Biomechanical analysis from smartphone videos.

Example:

    ```python
    from modelhealth import ModelHealthService, SubjectParameters

    service = ModelHealthService("your_api_key")

    sessions = service.session_list()
    subjects = service.subject_list()
    ```
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import StrEnum
from typing import Union

from ._modelhealth import (
    ModelHealthService as _ModelHealthService,
    # Exception hierarchy
    ModelHealthError,
    AuthenticationError,
    NotFoundError,
    NetworkError,
    # Entity types
    Session,
    Activity,
    ActivityResult,
    Video,
    Subject,
    SubjectParameters,
    ActivityTag,
    MotionData,
    AnalysisData,
    Analysis,
    Archive,
    CheckerboardDetails,
    # Native status types used internally for conversion
    ActivityStatusUploading as _PyActivityStatusUploading,
    ActivityStatusProcessing as _PyActivityStatusProcessing,
    ActivityStatusReady as _PyActivityStatusReady,
    ActivityStatusAnalyzing as _PyActivityStatusAnalyzing,
    ActivityStatusFailed as _PyActivityStatusFailed,
    AnalysisStatusProcessing as _PyAnalysisStatusProcessing,
    AnalysisStatusCompleted as _PyAnalysisStatusCompleted,
    AnalysisStatusFailed as _PyAnalysisStatusFailed,
    ArchiveStatusProcessing as _PyArchiveStatusProcessing,
    ArchiveStatusReady as _PyArchiveStatusReady,
    ArchiveStatusFailed as _PyArchiveStatusFailed,
    CalibrationStatusRecording as _PyCalibrationStatusRecording,
    CalibrationStatusUploading as _PyCalibrationStatusUploading,
    CalibrationStatusProcessing as _PyCalibrationStatusProcessing,
    CalibrationStatusDone as _PyCalibrationStatusDone,
    FilterFrequencyDefault,
    FilterFrequencyHz,
    ImportStatusCreatingSession as _PyImportStatusCreatingSession,
    ImportStatusCreatedSession as _PyImportStatusCreatedSession,
    ImportStatusUploadingVideo as _PyImportStatusUploadingVideo,
    ImportStatusProcessing as _PyImportStatusProcessing,
)

__version__ = "0.3.0"

# ---------------------------------------------------------------------------
# Status types
# ---------------------------------------------------------------------------


class MotionDataType(StrEnum):
    """Motion data types available for download from a processed activity.

    Pass one or more values to :meth:`ModelHealthService.motion_data_for_activity`.

    Example:

        ```python
        results = service.motion_data_for_activity(
            activity,
            [MotionDataType.kinematics_mot, MotionDataType.animation],
        )
        ```
    """

    animation = "animation"
    """Visualisation transforms. JSON format."""
    kinematics_mot = "kinematics_mot"
    """Inverse-kinematics results. MOT format."""
    kinematics_csv = "kinematics_csv"
    """Inverse-kinematics results. CSV format."""
    markers_trc = "markers_trc"
    """Marker trajectories. TRC format."""
    markers_csv = "markers_csv"
    """Marker trajectories. CSV format."""
    model = "model"
    """OpenSim musculoskeletal model. OSim format."""


class AnalysisDataType(StrEnum):
    """Analysis result types available for download after a completed analysis.

    Pass one or more values to :meth:`ModelHealthService.analysis_data_for_activity`.

    Example:

        ```python
        results = service.analysis_data_for_activity(
            activity,
            [AnalysisDataType.metrics, AnalysisDataType.report],
        )
        ```
    """

    metrics = "metrics"
    """Computed biomechanical metrics. JSON format."""
    report = "report"
    """Analysis report. PDF format."""
    data = "data"
    """Raw analysis data. ZIP format."""


class VideoVersion(StrEnum):
    """Video version to download for an activity.

    Pass to :meth:`ModelHealthService.videos_for_activity`.
    """

    raw = "raw"
    """Original per-camera recordings."""
    synced = "synced"
    """Temporally-synchronised output."""


class ActivitySort(StrEnum):
    """Sort order for activity lists.

    Pass to :meth:`ModelHealthService.activities_for_subject`.
    """

    updated_at = "updated_at"
    """Most recently updated first."""


class ActivityType(StrEnum):
    """Analysis algorithm to run on an activity.

    Pass to :meth:`ModelHealthService.start_analysis`.

    Example:

        ```python
        task = service.start_analysis(
            ActivityType.counter_movement_jump, activity, session
        )
        ```
    """

    counter_movement_jump = "counter_movement_jump"
    gait = "gait"
    treadmill_gait = "treadmill_gait"
    treadmill_running = "treadmill_running"
    overground_running = "overground_running"
    sit_to_stand = "sit_to_stand"
    squats = "squats"
    range_of_motion = "range_of_motion"
    drop_jump = "drop_jump"
    hop = "hop"
    change_of_direction = "change_of_direction"
    cut = "cut"


class ActivityConfig:
    """Configuration for starting a recording.

    Attributes:
        activity_type: The type of activity being recorded. When set, the
            corresponding analysis starts automatically once the recording
            is processed.
    """

    def __init__(self, activity_type: ActivityType) -> None:
        self.activity_type: ActivityType = activity_type


class AnalysisStatus(StrEnum):
    """The current state of an analysis task.

    Poll :meth:`ModelHealthService.analysis_status` after calling
    :meth:`ModelHealthService.start_analysis` to monitor progress.
    When status reaches ``completed``, download results with
    :meth:`ModelHealthService.analysis_data_for_activity`.

    Example:

        ```python
        import time

        status = service.analysis_status(task)
        while status == AnalysisStatus.processing:
            time.sleep(10)
            status = service.analysis_status(task)

        if status == AnalysisStatus.completed:
            results = service.analysis_data_for_activity(activity, [AnalysisDataType.metrics])
        ```
    """

    processing = "processing"
    """Analysis is in progress."""
    completed = "completed"
    """Analysis completed successfully."""
    failed = "failed"
    """Analysis failed."""


class ArchiveStatus(StrEnum):
    """The current state of an archive preparation task.

    Poll :meth:`ModelHealthService.archive_status` after calling
    :meth:`ModelHealthService.prepare_archive` to monitor progress.
    When status reaches ``ready``, download the archive with
    :meth:`ModelHealthService.archive_data`.

    Example:

        ```python
        import time

        archive = service.prepare_archive(session)
        status = service.archive_status(archive)
        while status == ArchiveStatus.processing:
            time.sleep(5)
            status = service.archive_status(archive)

        if status == ArchiveStatus.ready:
            data = service.archive_data(archive)
        ```
    """

    processing = "processing"
    """Archive is being prepared."""
    ready = "ready"
    """Archive is ready to download."""
    failed = "failed"
    """Archive preparation failed."""


class ActivityStatus(StrEnum):
    """The processing state of an activity (non-uploading variants).

    Activities must reach ``ready`` before analysis can begin.
    When videos are still uploading, :meth:`ModelHealthService.activity_status`
    returns :class:`ActivityStatusUploading` instead.

    Poll :meth:`ModelHealthService.activity_status` after recording stops to
    track upload and processing progress. Once ``ready``, pass the activity to
    :meth:`ModelHealthService.start_analysis`.

    Example:

        ```python
        import time

        status = service.activity_status(activity)
        while status == ActivityStatus.processing:
            time.sleep(5)
            status = service.activity_status(activity)

        if status == ActivityStatus.ready:
            task = service.start_analysis(ActivityType.counter_movement_jump, activity, session)
        elif status == ActivityStatus.failed:
            print("Processing failed")
        ```
    """

    processing = "processing"
    """Videos have been uploaded and are being processed."""
    ready = "ready"
    """Processing is complete. The activity is ready for analysis."""
    failed = "failed"
    """Processing failed."""


class CheckerboardPlacement(StrEnum):
    """Orientation of the calibration checkerboard relative to the ground.

    Pass to :class:`CheckerboardDetails`.
    """

    perpendicular = "perpendicular"
    """Checkerboard upright, plane perpendicular to the ground."""
    parallel = "parallel"
    """Checkerboard flat on the floor, plane parallel to the ground."""


class CalibrationStatus(StrEnum):
    """The current state of a calibration process (non-uploading, non-processing variants).

    When videos are uploading, :meth:`ModelHealthService.calibrate_camera` and
    :meth:`ModelHealthService.calibrate_subject` pass :class:`CalibrationStatusUploading`
    to the callback. When the server is processing, :class:`CalibrationStatusProcessing`
    is passed instead.
    """

    recording = "recording"
    """All connected cameras are actively recording."""
    done = "done"
    """Calibration completed successfully."""


class SessionFramerate(StrEnum):
    """Camera frame rate for a recording session.

    Higher framerates capture fast movements more accurately but increase
    processing time proportionally. Collect only as much footage as needed
    and keep recordings under the suggested durations.

    Pass to :meth:`ModelHealthService.configure_session`.
    """

    fps_60 = "fps_60"
    """60 frames per second. Suggested maximum recording duration: 60 s."""
    fps_120 = "fps_120"
    """120 frames per second (default). Suggested maximum recording duration: 30 s."""
    fps_240 = "fps_240"
    """240 frames per second. Suggested maximum recording duration: 15 s."""


class SessionOpenSimModel(StrEnum):
    """OpenSim musculoskeletal model used for biomechanical analysis.

    Pass to :meth:`ModelHealthService.configure_session`.
    """

    lai_uhlrich_2022_shoulder = "lai_uhlrich_2022_shoulder"
    """Full-body model with 33 degrees of freedom plus a 6-DoF shoulder
    complex with a scapulothoracic body and a glenohumeral joint using the
    ISB-recommended Y-X-Y rotation sequence. Default."""
    lai_uhlrich_2022 = "lai_uhlrich_2022"
    """Same full-body model as ``lai_uhlrich_2022_shoulder`` without the
    ISB shoulder complex."""


class SessionScalingSetup(StrEnum):
    """Pose used for subject scaling during calibration.

    Pass to :meth:`ModelHealthService.configure_session`.
    """

    upright_standing_pose = "upright_standing_pose"
    """Subject stands straight with feet pointing forward and no bending or
    rotation at the hips, knees, or ankles. Default."""
    any_pose = "any_pose"
    """No posture assumptions. Use when the subject cannot adopt the upright
    standing pose. Requires all body segments to be visible by at least two
    cameras."""


class SessionCoreEngine(StrEnum):
    """Core processing engine version.

    Pass to :meth:`ModelHealthService.configure_session`.
    """

    v0_2 = "v0_2"
    """Version 0.2."""
    v0_3 = "v0_3"
    """Version 0.3 (default)."""
    v1_0 = "v1_0"
    """Version 1.0. Currently in beta."""


class SessionDataSharing(StrEnum):
    """Data-sharing preference for a session.

    Session data and videos are uploaded to a secure cloud server for
    processing. This setting controls what Model Health can use for internal
    development. Identified videos contain original footage with faces
    unblurred; de-identified videos have faces blurred. Processed data
    (e.g. joint angles) is always de-identified.

    Pass to :meth:`ModelHealthService.configure_session`.
    """

    share_processed_data_and_identified_videos = "share_processed_data_and_identified_videos"
    """Share processed data and identified videos (default)."""
    share_processed_data_and_deidentified_videos = "share_processed_data_and_deidentified_videos"
    """Share processed data and de-identified videos (faces blurred)."""
    share_processed_data = "share_processed_data"
    """Share processed data only. No videos are shared."""
    share_no_data = "share_no_data"
    """Share no data for internal development."""


@dataclass(frozen=True)
class CalibrationStatusUploading:
    """Videos are being uploaded from cameras.

    Passed to the status callback when upload is in progress.
    ``uploaded`` and ``total`` track progress.
    """

    uploaded: int
    """Number of videos successfully uploaded so far."""
    total: int
    """Total number of videos expected from all cameras."""


@dataclass(frozen=True)
class CalibrationStatusProcessing:
    """The server is processing the uploaded videos.

    Passed to the status callback during server-side processing.
    ``percent`` is the completion percentage, or ``None`` if unavailable.
    """

    percent: int | None
    """Processing completion percentage (0–100), or ``None`` if unavailable."""


@dataclass(frozen=True)
class ActivityStatusUploading:
    """Videos are being uploaded from cameras.

    Returned by :meth:`ModelHealthService.activity_status` when upload is in
    progress. ``uploaded`` and ``total`` track progress.

    Example:

        ```python
        status = service.activity_status(activity)
        if isinstance(status, ActivityStatusUploading):
            print(f"Uploading: {status.uploaded}/{status.total}")
        ```
    """

    uploaded: int
    """Number of videos successfully uploaded so far."""
    total: int
    """Total number of videos expected from all cameras."""


@dataclass(frozen=True)
class ActivityStatusAnalyzing:
    """Analysis has been triggered and is in progress.

    Returned by :meth:`ModelHealthService.activity_status` after processing
    completes when an activity type was set at recording time. Pass ``task``
    to :meth:`ModelHealthService.analysis_status` to track analysis progress.

    Example:

        ```python
        status = service.activity_status(activity)
        if isinstance(status, ActivityStatusAnalyzing):
            analysis_status = service.analysis_status(status.task)
        ```
    """

    task: Analysis
    """The analysis task. Pass to :meth:`ModelHealthService.analysis_status`."""


@dataclass(frozen=True)
class ImportStatusCreatedSession:
    """Session created successfully during a session import.

    Passed to the status callback during :meth:`ModelHealthService.import_session`
    once the new session has been created on the server.
    """

    session_id: str
    """ID of the newly created session."""


@dataclass(frozen=True)
class ImportStatusUploading:
    """A video is being uploaded during a session import.

    Passed to the status callback during :meth:`ModelHealthService.import_session`
    while videos are being transferred. ``trial`` names the current trial;
    ``uploaded`` and ``total`` track progress within that trial.
    """

    trial: str
    """Name of the trial whose video is being uploaded."""
    uploaded: int
    """Number of videos successfully uploaded so far."""
    total: int
    """Total number of videos to upload."""


@dataclass
class SessionConfig:
    """Settings to apply to a session before recording.

    All fields have sensible defaults. Pass to
    :meth:`ModelHealthService.import_session` (or call
    :meth:`ModelHealthService.configure_session` directly) to override.

    Example:

        ```python
        from modelhealth import SessionConfig, SessionFramerate, SessionDataSharing

        config = SessionConfig(
            framerate=SessionFramerate.fps_60,
            data_sharing=SessionDataSharing.share_no_data,
        )
        session = service.import_session(activities_json, subject, session_config=config)
        ```
    """

    framerate: SessionFramerate = SessionFramerate.fps_120
    """Camera frame rate. Default: ``fps_120``."""
    opensim_model: SessionOpenSimModel = SessionOpenSimModel.lai_uhlrich_2022_shoulder
    """OpenSim musculoskeletal model. Default: ``lai_uhlrich_2022_shoulder``."""
    scaling_setup: SessionScalingSetup = SessionScalingSetup.upright_standing_pose
    """Scaling pose. Default: ``upright_standing_pose``."""
    core_engine: SessionCoreEngine = SessionCoreEngine.v0_3
    """Core processing engine version. Default: ``v0_3``."""
    filter_frequency: Union[FilterFrequencyDefault, FilterFrequencyHz] = None  # type: ignore[assignment]
    """Low-pass filter frequency. Default: server-chosen."""
    data_sharing: SessionDataSharing = SessionDataSharing.share_processed_data_and_identified_videos
    """Data-sharing preference. Default: ``share_processed_data_and_identified_videos``."""

    def __post_init__(self) -> None:
        if self.filter_frequency is None:
            self.filter_frequency = FilterFrequencyDefault()


# ---------------------------------------------------------------------------
# Internal status conversion helpers
# ---------------------------------------------------------------------------


def _to_activity_status(
    raw: object,
) -> Union[ActivityStatus, ActivityStatusUploading, ActivityStatusAnalyzing]:
    if isinstance(raw, _PyActivityStatusUploading):
        return ActivityStatusUploading(uploaded=raw.uploaded, total=raw.total)
    if isinstance(raw, _PyActivityStatusProcessing):
        return ActivityStatus.processing
    if isinstance(raw, _PyActivityStatusReady):
        return ActivityStatus.ready
    if isinstance(raw, _PyActivityStatusAnalyzing):
        return ActivityStatusAnalyzing(task=raw.task)
    if isinstance(raw, _PyActivityStatusFailed):
        return ActivityStatus.failed
    raise RuntimeError(f"Unexpected activity status type: {type(raw)}")  # pragma: no cover


def _to_analysis_status(raw: object) -> AnalysisStatus:
    if isinstance(raw, _PyAnalysisStatusProcessing):
        return AnalysisStatus.processing
    if isinstance(raw, _PyAnalysisStatusCompleted):
        return AnalysisStatus.completed
    if isinstance(raw, _PyAnalysisStatusFailed):
        return AnalysisStatus.failed
    raise RuntimeError(f"Unexpected analysis status type: {type(raw)}")  # pragma: no cover


def _to_archive_status(raw: object) -> ArchiveStatus:
    if isinstance(raw, _PyArchiveStatusProcessing):
        return ArchiveStatus.processing
    if isinstance(raw, _PyArchiveStatusReady):
        return ArchiveStatus.ready
    if isinstance(raw, _PyArchiveStatusFailed):
        return ArchiveStatus.failed
    raise RuntimeError(f"Unexpected archive status type: {type(raw)}")  # pragma: no cover


def _to_calibration_status(
    raw: object,
) -> Union[CalibrationStatus, CalibrationStatusUploading, CalibrationStatusProcessing]:
    if isinstance(raw, _PyCalibrationStatusRecording):
        return CalibrationStatus.recording
    if isinstance(raw, _PyCalibrationStatusUploading):
        return CalibrationStatusUploading(uploaded=raw.uploaded, total=raw.total)
    if isinstance(raw, _PyCalibrationStatusProcessing):
        return CalibrationStatusProcessing(percent=raw.percent)
    if isinstance(raw, _PyCalibrationStatusDone):
        return CalibrationStatus.done
    raise RuntimeError(f"Unexpected calibration status type: {type(raw)}")  # pragma: no cover


def _to_import_status(
    raw: object,
) -> Union["ImportStatusCreatedSession", "ImportStatusUploading", str]:
    if isinstance(raw, _PyImportStatusCreatingSession):
        return "creating_session"
    if isinstance(raw, _PyImportStatusCreatedSession):
        return ImportStatusCreatedSession(session_id=raw.session_id)
    if isinstance(raw, _PyImportStatusUploadingVideo):
        return ImportStatusUploading(trial=raw.trial, uploaded=raw.uploaded, total=raw.total)
    if isinstance(raw, _PyImportStatusProcessing):
        return "processing"
    raise RuntimeError(f"Unexpected transfer status type: {type(raw)}")  # pragma: no cover


# ---------------------------------------------------------------------------
# Service
# ---------------------------------------------------------------------------


class ModelHealthService:
    """Client for the Model Health biomechanical analysis platform.

    Enables you to measure and analyze human movement from smartphone videos.
    Provides a complete workflow for:

    1. **Initialization**: Create a service with your API key
    2. **Session Creation**: Create a session
    3. **Camera Calibration**: Calibrate cameras using a checkerboard pattern
    4. **Subject Creation**: Create a subject profile with anthropometric measurements
    5. **Subject Calibration**: Calibrate subject using videos of a neutral pose
    6. **Movement Recording**: Record movement activities (squats, jumps, etc.)
    7. **Movement Analysis**: Trigger advanced analysis and fetch processed biomechanical data

    All methods are synchronous and block until the underlying operation
    completes. Each instance owns a dedicated single-threaded
    async runtime so instances may be used across threads, but a single
    instance should not be called concurrently from multiple threads.

    Example:

        ```python
        from modelhealth import (
            ModelHealthService, SubjectParameters, CheckerboardDetails,
            CheckerboardPlacement, ActivityType,
        )

        service = ModelHealthService("your_api_key")

        # Create session and calibrate cameras
        session = service.create_session()
        details = CheckerboardDetails(rows=4, columns=5, square_size=35, placement=CheckerboardPlacement.perpendicular)
        service.calibrate_camera(session, details, lambda s: print(s))

        # Create subject and calibrate
        params = SubjectParameters(name="Jane Doe", weight=65.0, height=170.0, birth_year=1990)
        subject = service.create_subject(params)
        service.calibrate_subject(subject, session, lambda s: print(s))

        # Record a movement activity
        activity = service.start_recording("cmj", session)
        # Subject performs movement...
        service.stop_recording(session)
        ```
    """


    def __init__(self, api_key: str) -> None:
        """Initialises the service and validates the API key format.

        Args:
            api_key: Your Model Health API key, available in the dashboard
                at modelhealth.io.

        Raises:
            AuthenticationError: If the API key is empty or invalid.

        Example:

            ```python
            from modelhealth import ModelHealthService

            service = ModelHealthService("your_api_key")

            # List sessions and subjects
            sessions = service.session_list()
            subjects = service.subject_list()
            ```
        """
        self._svc = _ModelHealthService(api_key)

    # ------------------------------------------------------------------
    # Sessions
    # ------------------------------------------------------------------

    def session_list(self) -> list[Session]:
        """Retrieves all sessions for the account associated with the API key.

        Use this to list existing sessions before creating a new one, or to
        resume a previous capture workflow.

        To connect a device to a specific session, use the session ``qrcode``
        URL to download the QR code image data, then display it in your app
        to be captured by the ModelHealth mobile app.

        Returns:
            A list of :class:`Session` objects, or an empty list if none exist.

        Raises:
            AuthenticationError: If the API key is invalid or expired.
            NetworkError: On connection failure or timeout.
            ModelHealthError: On server error or unexpected response.

        Example:

            ```python
            import urllib.request

            sessions = service.session_list()
            print(f"Found {len(sessions)} sessions")

            if sessions:
                first = sessions[0]
                with urllib.request.urlopen(first.qrcode) as resp:
                    qr_image_data = resp.read()
                # Display qr_image_data in your app so the mobile app can scan it
            ```
        """
        return self._svc.session_list()

    def get_session(self, session_id: str) -> Session:
        """Retrieve a specific session by ID with all activities populated.

        Args:
            session_id: The ``id`` of the session to retrieve.

        Returns:
            A :class:`Session` with ``activities`` populated.

        Raises:
            AuthenticationError: If the API key is invalid or expired.
            NotFoundError: If the session does not exist.
            NetworkError: On connection failure or timeout.
            ModelHealthError: On server error or unexpected response.

        Example:

            ```python
            session = service.get_session("abc123")
            for activity in session.activities:
                print(f"{activity.name or activity.id}")
            ```
        """
        return self._svc.get_session(session_id)

    def create_session(self) -> Session:
        """Creates a session.

        A session is the parent container for a movement capture workflow. It
        links related entities such as activities and subjects and provides
        the context used by subsequent operations.

        Default session settings are applied automatically. Call
        :meth:`configure_session` afterwards to override specific settings.

        Returns:
            A new :class:`Session` with a unique identifier.

        Raises:
            AuthenticationError: If the API key is invalid or expired.
            NetworkError: On connection failure or timeout.
            ModelHealthError: On server error or unexpected response.

        Example:

            ```python
            session = service.create_session()
            ```
        """
        return self._svc.create_session()

    def configure_session(
        self,
        session: Session,
        framerate: SessionFramerate = SessionFramerate.fps_120,
        opensim_model: SessionOpenSimModel = SessionOpenSimModel.lai_uhlrich_2022_shoulder,
        scaling_setup: SessionScalingSetup = SessionScalingSetup.upright_standing_pose,
        core_engine: SessionCoreEngine = SessionCoreEngine.v0_3,
        filter_frequency: Union[FilterFrequencyDefault, FilterFrequencyHz] = FilterFrequencyDefault(),
        data_sharing: SessionDataSharing = SessionDataSharing.share_processed_data_and_identified_videos,
    ) -> None:
        """Applies settings to an existing session.

        Call this after :meth:`create_session` and before calibration to
        override any default settings. If not called, the session retains the
        defaults applied during creation.

        All parameters are optional — omit any to keep its default.

        Args:
            session: The session to configure.
            framerate: Camera frame rate. Default: ``SessionFramerate.fps_120``.
            opensim_model: OpenSim model. Default:
                ``SessionOpenSimModel.lai_uhlrich_2022_shoulder``.
            scaling_setup: Scaling pose. Default:
                ``SessionScalingSetup.upright_standing_pose``.
            core_engine: Core engine version. Default: ``SessionCoreEngine.v0_3``.
            filter_frequency: Low-pass filter frequency. Default:
                ``FilterFrequencyDefault()``.
            data_sharing: Data-sharing preference. Default:
                ``SessionDataSharing.share_processed_data_and_identified_videos``.

        Raises:
            AuthenticationError: If the API key is invalid or expired.
            NetworkError: On connection failure or timeout.
            ModelHealthError: On server error or unexpected response.

        Example:

            ```python
            session = service.create_session()
            service.configure_session(
                session,
                framerate=SessionFramerate.fps_60,
                data_sharing=SessionDataSharing.share_no_data,
            )
            ```
        """
        self._svc.configure_session(
            session,
            str(framerate),
            str(opensim_model),
            str(scaling_setup),
            str(core_engine),
            filter_frequency,
            str(data_sharing),
        )

    # ------------------------------------------------------------------
    # Subjects
    # ------------------------------------------------------------------

    def subject_list(self) -> list[Subject]:
        """Retrieves all subjects associated with the API key.

        Subjects represent individuals being monitored or assessed. Each
        subject may contain demographic information, physical measurements,
        and categorization tags.

        Returns:
            A list of :class:`Subject` objects, or an empty list if none exist.

        Raises:
            AuthenticationError: If the API key is invalid or expired.
            NetworkError: On connection failure or timeout.
            ModelHealthError: On server error or unexpected response.

        Example:

            ```python
            subjects = service.subject_list()
            for subject in subjects:
                print(f"{subject.name}: {subject.height}cm, {subject.weight}kg")
            ```
        """
        return self._svc.subject_list()

    def create_subject(self, parameters: SubjectParameters) -> Subject:
        """Creates a subject profile.

        Height and weight are required for biomechanical analysis. Once
        created, the subject can be calibrated using
        :meth:`calibrate_subject`.

        Args:
            parameters: The subject's profile details including name and
                anthropometrics.

        Returns:
            The newly created :class:`Subject` with its assigned ID.

        Raises:
            AuthenticationError: If the API key is invalid or expired.
            NetworkError: On connection failure or timeout.
            ModelHealthError: On validation failure, server error or unexpected
                response.

        Example:

            ```python
            from modelhealth import SubjectParameters

            params = SubjectParameters(
                name="John Smith",
                weight=75.0,
                height=180.0,
                birth_year=1990,
            )
            subject = service.create_subject(params)
            print(f"Created subject with ID: {subject.id}")

            # Use the subject for calibration
            service.calibrate_subject(subject, session, lambda s: print(s))
            ```
        """
        return self._svc.create_subject(parameters)

    # ------------------------------------------------------------------
    # Activities
    # ------------------------------------------------------------------

    def activities_for_subject(
        self,
        subject: Subject,
        start_index: int,
        count: int,
        sort: ActivitySort = ActivitySort.updated_at,
    ) -> list[Activity]:
        """Retrieves activities for a specific subject with pagination and sorting.

        Use this to display a subject's activity history or implement
        paginated list interfaces.

        Args:
            subject: The subject whose activities to retrieve.
            start_index: Zero-based index to start from. Use ``0`` for the
                first page.
            count: Number of activities to retrieve per request.
            sort: Sort order — currently only ``"updated_at"``
                (most recently updated first).

        Returns:
            A list of :class:`Activity` objects, or an empty list if none
            exist.

        Raises:
            AuthenticationError: If the API key is invalid or expired.
            NetworkError: On connection failure or timeout.
            ModelHealthError: On server error or unexpected response.

        Example:

            ```python
            # First page
            page1 = service.activities_for_subject(
                subject, start_index=0, count=20
            )

            # Next page
            page2 = service.activities_for_subject(
                subject, start_index=20, count=20
            )
            ```
        """
        return self._svc.activities_for_subject(subject.id, start_index, count, sort)

    def fetch_activity(self, activity_id: str) -> Activity:
        """Retrieves an activity by its ID.

        Use this to fetch the latest state of an activity, including its
        videos, results and current processing status.

        Args:
            activity_id: The unique identifier of the activity.

        Returns:
            The :class:`Activity` with its current details.

        Raises:
            AuthenticationError: If the API key is invalid or expired.
            NotFoundError: If the activity does not exist.
            NetworkError: On connection failure or timeout.
            ModelHealthError: On server error or unexpected response.

        Example:

            ```python
            activity = service.fetch_activity("abc123")
            print(f"Activity: {activity.name or 'Unnamed'}")
            print(f"Status: {activity.status}")
            ```
        """
        return self._svc.fetch_activity(activity_id)

    def update_activity(self, activity: Activity) -> Activity:
        """Updates an activity.

        Only mutable fields (such as ``name``) are applied on the server.
        Use the returned object rather than the input going forward.

        Args:
            activity: The :class:`Activity` to update, with modified
                properties.

        Returns:
            The updated :class:`Activity` as stored on the server.

        Raises:
            AuthenticationError: If the API key is invalid or expired.
            NotFoundError: If the activity does not exist.
            NetworkError: On connection failure or timeout.
            ModelHealthError: On server error or unexpected response.
        """
        return self._svc.update_activity(activity)

    def delete_activity(self, activity: Activity) -> None:
        """Deletes an activity.

        Permanently removes the activity and all associated videos, results,
        and metadata.

        Args:
            activity: The :class:`Activity` to delete.

        Raises:
            AuthenticationError: If the API key is invalid or expired.
            NotFoundError: If the activity does not exist.
            NetworkError: On connection failure or timeout.
            ModelHealthError: On server error or unexpected response.

        Example:

            ```python
            service.delete_activity(activity)
            ```

        Warning:
            This operation is irreversible.
        """
        self._svc.delete_activity(activity)

    def activity_tags(self) -> list[ActivityTag]:
        """Retrieves all available activity tags.

        Use the returned tags to populate a tag picker or validate tag values
        before assigning them to activities.

        Returns:
            A list of :class:`ActivityTag` objects, or an empty list if none
            are configured.

        Raises:
            AuthenticationError: If the API key is invalid or expired.
            NetworkError: On connection failure or timeout.
            ModelHealthError: On server error or unexpected response.

        Example:

            ```python
            tags = service.activity_tags()
            for tag in tags:
                print(f"{tag.label}: {tag.value}")
            ```
        """
        return self._svc.activity_tags()

    # ------------------------------------------------------------------
    # Activities (by session)
    # ------------------------------------------------------------------

    def activity_list(self, session: Session) -> list[Activity]:
        """Retrieves all movement activities associated with a session.

        Activities represent individual recording trials and contain
        references to captured videos and results. Use this to review past
        data or fetch results for completed activities.

        Args:
            session: The session whose activities to retrieve.

        Returns:
            A list of :class:`Activity` objects, or an empty list if none
            exist.

        Raises:
            AuthenticationError: If the API key is invalid or expired.
            NetworkError: On connection failure or timeout.
            ModelHealthError: On server error or unexpected response.

        Example:

            ```python
            activities = service.activity_list(session)
            for activity in activities:
                print(f"{activity.name or activity.id}")
                print(f"  Videos: {len(activity.videos)}")
                print(f"  Results: {len(activity.results)}")
            ```
        """
        return self._svc.activity_list(session.id)

    # ------------------------------------------------------------------
    # Downloads
    # ------------------------------------------------------------------

    def videos_for_activity(
        self,
        activity: Activity,
        version: VideoVersion,
    ) -> list[bytes]:
        """Downloads video data for a specific activity.

        Fetches all videos associated with the activity that match the
        specified version. Videos with invalid URLs or failed downloads are
        silently excluded from the result.

        Args:
            activity: The :class:`Activity` whose videos to download.
            version: :attr:`VideoVersion.raw` for original per-camera recordings, or
                :attr:`VideoVersion.synced` for temporally-synchronised output.

        Returns:
            A list of raw video bytes (one per camera). Write each element
            to a ``.mp4`` file for playback. May be empty if no videos are
            available or all downloads fail.

        Raises:
            AuthenticationError: If the API key is invalid or expired.
            NetworkError: On connection failure or timeout.
            ModelHealthError: On server error or unexpected response.

        Example:

            ```python
            videos = service.videos_for_activity(activity, VideoVersion.synced)
            for i, video in enumerate(videos):
                with open(f"video_{i}.mp4", "wb") as f:
                    f.write(video)
            ```
        """
        return self._svc.videos_for_activity(activity, version)

    def motion_data_for_activity(
        self,
        activity: Activity,
        data_types: list[MotionDataType],
    ) -> list[MotionData]:
        """Downloads motion data from a processed activity.

        Use this after an activity reaches ``ActivityStatus.ready`` to
        retrieve biomechanical result files such as kinematics, marker
        data, or an OpenSim model. Failed downloads are silently excluded
        from results.

        Args:
            activity: The :class:`Activity` whose results to download. Must
                have completed processing.
            data_types: Motion data types to fetch. Valid values:
                ``"animation"``, ``"kinematics_mot"``, ``"kinematics_csv"``,
                ``"markers_trc"``, ``"markers_csv"``, ``"model"``.

        Returns:
            A list of :class:`MotionData` objects, one per successfully
            downloaded type. May be empty if no results are available or
            all downloads fail.

        Raises:
            AuthenticationError: If the API key is invalid or expired.
            NetworkError: On connection failure or timeout.
            ModelHealthError: On server error or unexpected response.

        Example:

            ```python
            results = service.motion_data_for_activity(
                activity, [MotionDataType.kinematics_mot, MotionDataType.animation]
            )
            for r in results:
                if r.type == "kinematics_mot":
                    with open("kinematics.mot", "wb") as f:
                        f.write(r.data)  # MOT format
                elif r.type == "animation":
                    import json
                    transforms = json.loads(r.data)  # JSON format
                elif r.type == "markers_trc":
                    with open("markers.trc", "wb") as f:
                        f.write(r.data)  # TRC format
                elif r.type == "model":
                    with open("model.osim", "wb") as f:
                        f.write(r.data)  # OSim format
            ```
        """
        return self._svc.motion_data_for_activity(activity, data_types)

    def analysis_data_for_activity(
        self,
        activity: Activity,
        data_types: list[AnalysisDataType],
    ) -> list[AnalysisData]:
        """Downloads result data for an activity with a completed analysis.

        Call this after :meth:`analysis_status` returns
        ``AnalysisStatus.completed`` to retrieve metrics, a report, or raw
        data. Failed downloads are silently excluded from results.

        Args:
            activity: The :class:`Activity` whose analysis results to
                download. Must have a completed analysis.
            data_types: Analysis result types to fetch. Valid values:
                ``"metrics"`` (JSON), ``"report"`` (PDF), ``"data"`` (ZIP).

        Returns:
            A list of :class:`AnalysisData` objects, one per successfully
            downloaded type. May be empty if no results are available or
            all downloads fail.

        Raises:
            AuthenticationError: If the API key is invalid or expired.
            NetworkError: On connection failure or timeout.
            ModelHealthError: On server error or unexpected response.

        Example:

            ```python
            import json

            results = service.analysis_data_for_activity(
                activity, [AnalysisDataType.metrics, AnalysisDataType.report, AnalysisDataType.data]
            )
            for r in results:
                if r.type == "metrics":
                    metrics = json.loads(r.data)
                elif r.type == "report":
                    with open("report.pdf", "wb") as f:
                        f.write(r.data)
                elif r.type == "data":
                    with open("data.zip", "wb") as f:
                        f.write(r.data)
            ```
        """
        return self._svc.analysis_data_for_activity(activity, data_types)

    # ------------------------------------------------------------------
    # Analysis
    # ------------------------------------------------------------------

    def activity_status(
        self, activity: Activity
    ) -> Union[ActivityStatus, ActivityStatusUploading, ActivityStatusAnalyzing]:
        """Retrieves the current processing status of an activity.

        Poll this method after recording stops to track upload and processing
        progress.

        Returns :class:`ActivityStatusUploading` when videos are uploading,
        :class:`ActivityStatusAnalyzing` (with the analysis task) when automatic
        analysis is running, or an :class:`ActivityStatus` enum value otherwise.

        Args:
            activity: The :class:`Activity` to check status for.

        Returns:
            The current status as :class:`ActivityStatusUploading`,
            :class:`ActivityStatusAnalyzing`, or :class:`ActivityStatus`.

        Raises:
            AuthenticationError: If the API key is invalid or expired.
            NetworkError: On connection failure or timeout.
            ModelHealthError: On server error or unexpected response.

        Example:

            ```python
            status = service.activity_status(activity)
            if isinstance(status, ActivityStatusUploading):
                print(f"Uploading: {status.uploaded}/{status.total}")
            elif status == ActivityStatus.processing:
                print("Still processing...")
            elif isinstance(status, ActivityStatusAnalyzing):
                analysis_status = service.analysis_status(status.task)
            elif status == ActivityStatus.ready:
                print("Activity ready for analysis")
            elif status == ActivityStatus.failed:
                print("Processing failed")
            ```
        """
        return _to_activity_status(self._svc.activity_status(activity))

    def start_analysis(
        self,
        activity_type: ActivityType,
        activity: Activity,
        session: Session,
    ) -> Analysis:
        """Starts an analysis task for an activity that is ready for analysis.

        Call this after :meth:`activity_status` returns
        ``ActivityStatus.ready``. Use the returned :class:`Analysis` with
        :meth:`analysis_status` to poll progress.

        Args:
            activity_type: The analysis algorithm to run.
                Use a :class:`ActivityType` member.
            activity: The :class:`Activity` to analyze.
            session: The :class:`Session` containing the activity.

        Returns:
            An :class:`Analysis` for tracking analysis progress.

        Raises:
            AuthenticationError: If the API key is invalid or expired.
            NetworkError: On connection failure or timeout.
            ModelHealthError: If the activity is not ready or the request
                fails.

        Example:

            ```python
            task = service.start_analysis(
                ActivityType.counter_movement_jump, activity, session
            )
            status = service.analysis_status(task)
            ```
        """
        return self._svc.start_analysis(activity_type, activity, session)

    def analysis_status(self, task: Analysis) -> AnalysisStatus:
        """Retrieves the current status of an analysis task.

        Poll this method after :meth:`start_analysis` to monitor progress.
        When status reaches ``AnalysisStatus.completed``, download results
        with :meth:`analysis_data_for_activity`.

        Args:
            task: The :class:`Analysis` task returned by
                :meth:`start_analysis`.

        Returns:
            The current :class:`AnalysisStatus`.

        Raises:
            AuthenticationError: If the API key is invalid or expired.
            NetworkError: On connection failure or timeout.
            ModelHealthError: On server error or unexpected response.

        Example:

            ```python
            import time

            status = service.analysis_status(task)
            while status == AnalysisStatus.processing:
                time.sleep(10)
                status = service.analysis_status(task)

            if status == AnalysisStatus.completed:
                results = service.analysis_data_for_activity(
                    activity, [AnalysisDataType.metrics, AnalysisDataType.report]
                )
            elif status == AnalysisStatus.failed:
                print("Analysis failed")
            ```
        """
        return _to_analysis_status(self._svc.analysis_status(task))

    # ------------------------------------------------------------------
    # Recording & Calibration
    # ------------------------------------------------------------------

    def start_recording(self, name: str, session: Session, config: ActivityConfig | None = None) -> Activity:
        """Creates an activity and starts recording a dynamic movement trial.

        Must be called after both camera and subject calibration are complete.
        Call :meth:`stop_recording` when the subject has finished the movement.

        Args:
            name: A descriptive name for this activity (e.g. ``"cmj"``, ``"squat"``).
            session: The session this activity is associated with.
            config: Optional recording configuration.

        Returns:
            The newly created :class:`Activity`.

        Raises:
            AuthenticationError: If the API key is invalid or expired.
            NetworkError: On connection failure or timeout.
            ModelHealthError: If recording cannot start (e.g. missing calibration).

        Example:

            ```python
            activity = service.start_recording("cmj", session, ActivityConfig(ActivityType.counter_movement_jump))
            # Subject performs movement...
            service.stop_recording(session)
            ```
        """
        return self._svc.start_recording(name, session, config.activity_type if config else None)

    def stop_recording(self, session: Session) -> None:
        """Stops the active recording for a movement trial.

        Call this after the subject has completed the movement. Once stopped,
        the recorded videos begin uploading and can be tracked with
        :meth:`activity_status`.

        Args:
            session: The session context to stop recording in.

        Raises:
            AuthenticationError: If the API key is invalid or expired.
            NetworkError: On connection failure or timeout.
            ModelHealthError: If there is no active recording or the request fails.

        Example:

            ```python
            service.stop_recording(session)
            ```
        """
        self._svc.stop_recording(session)

    def calibrate_camera(
        self,
        session: Session,
        checkerboard: CheckerboardDetails,
        status_callback: object,
    ) -> None:
        """Calibrates cameras using a checkerboard pattern.

        Determines each camera's position and orientation in 3D space
        (extrinsics), enabling reconstruction of real-world movement from
        multiple 2D video feeds. Required once per session setup — recalibrate
        only if cameras are moved.

        Note:
            ``rows`` and ``columns`` refer to internal corners, not squares.
            A 5×6 board has 4 internal corner rows and 5 internal corner
            columns.

        This method blocks until calibration completes. The ``status_callback``
        is called synchronously on each status update during the operation.

        Args:
            session: The session context in which calibration is performed.
            checkerboard: The checkerboard dimensions and placement.
            status_callback: Callable receiving a
                :class:`CalibrationStatus`, :class:`CalibrationStatusUploading`
                or :class:`CalibrationStatusProcessing` on each update.

        Raises:
            AuthenticationError: If the API key is invalid or expired.
            NetworkError: On connection failure or timeout.
            ModelHealthError: If calibration fails (e.g. pattern not detected).

        Example:

            ```python
            from modelhealth import CheckerboardDetails, CheckerboardPlacement

            details = CheckerboardDetails(
                rows=4,       # Internal corners, not squares (for 5×6 board)
                columns=5,    # Internal corners, not squares (for 5×6 board)
                square_size=35,  # Measured in millimeters
                placement=CheckerboardPlacement.perpendicular,
            )
            service.calibrate_camera(session, details, lambda s: print(s))
            ```
        """
        self._svc.calibrate_camera(
            session,
            checkerboard,
            lambda raw: status_callback(_to_calibration_status(raw)),
        )

    def calibrate_subject(
        self,
        subject: Subject,
        session: Session,
        status_callback: object,
    ) -> None:
        """Calibrates a subject by recording a neutral standing pose.

        Scales the 3D biomechanical model to the subject's body size. Must be
        run after camera calibration and requires the subject profile to include
        height and weight.

        Important:
            The subject must stand upright, feet pointing forward, completely
            still and fully visible to all cameras for the duration of the
            recording.

        This method blocks until calibration completes. The ``status_callback``
        is called synchronously on each status update during the operation.

        Args:
            subject: The subject to calibrate.
            session: The session context in which calibration is performed.
            status_callback: Callable receiving a
                :class:`CalibrationStatus`, :class:`CalibrationStatusUploading`
                or :class:`CalibrationStatusProcessing` on each update.

        Raises:
            AuthenticationError: If the API key is invalid or expired.
            NetworkError: On connection failure or timeout.
            ModelHealthError: If calibration fails.

        Example:

            ```python
            service.calibrate_subject(subject, session, lambda s: print(s))
            ```
        """
        self._svc.calibrate_subject(
            subject,
            session,
            lambda raw: status_callback(_to_calibration_status(raw)),
        )

    # ------------------------------------------------------------------
    # Archive
    # ------------------------------------------------------------------

    def prepare_archive(
        self,
        session: Session,
        with_videos: bool = False,
    ) -> Archive:
        """Starts preparing a session archive for download.

        Kicks off a server-side task that packages the session data into a ZIP
        file. Poll :meth:`archive_status` until status reaches
        ``ArchiveStatus.ready``, then call :meth:`archive_data` to download
        the ZIP file.

        Args:
            session: The :class:`Session` to archive.
            with_videos: If ``True``, include raw video files in the archive.
                Defaults to ``False``.

        Returns:
            An :class:`Archive` for tracking preparation progress.

        Raises:
            AuthenticationError: If the API key is invalid or expired.
            NetworkError: On connection failure or timeout.
            ModelHealthError: On server error or unexpected response.

        Example:

            ```python
            import time

            archive = service.prepare_archive(session)
            status = service.archive_status(archive)
            while status == ArchiveStatus.processing:
                time.sleep(5)
                status = service.archive_status(archive)

            if status == ArchiveStatus.ready:
                data = service.archive_data(archive)
                with open("session.zip", "wb") as f:
                    f.write(data)
            ```
        """
        return self._svc.prepare_archive(session, with_videos)

    def archive_status(self, archive: Archive) -> ArchiveStatus:
        """Retrieves the current preparation status of an archive task.

        Poll this method after :meth:`prepare_archive` to monitor progress.
        When status reaches ``ArchiveStatus.ready``, download the archive
        with :meth:`archive_data`.

        Args:
            archive: The :class:`Archive` task returned by
                :meth:`prepare_archive`.

        Returns:
            The current :class:`ArchiveStatus`.

        Raises:
            AuthenticationError: If the API key is invalid or expired.
            NetworkError: On connection failure or timeout.
            ModelHealthError: On server error or unexpected response.

        Example:

            ```python
            status = service.archive_status(archive)

            if status == ArchiveStatus.processing:
                print("Archive being prepared...")
            elif status == ArchiveStatus.ready:
                print("Archive ready to download")
            elif status == ArchiveStatus.failed:
                print("Archive preparation failed")
            ```
        """
        return _to_archive_status(self._svc.archive_status(archive))

    def import_session(
        self,
        activities_json: str,
        subject: Subject,
        session_config: SessionConfig | None = None,
        session_meta_json: str | None = None,
        status_callback=None,
    ) -> Session:
        """Imports a set of activities into Model Health.

        Performs the full import workflow: session creation, configuration,
        subject association, activity creation, video download and upload,
        processing trigger and polling until complete for each activity.

        Args:
            activities_json: Raw JSON string of a JSON array of activity objects.
            subject: Subject to associate with the session.
            session_config: Session settings. ``None`` uses defaults.
            session_meta_json: Optional JSON string of the source session's
                ``meta`` field. When provided, the new session is patched with
                this metadata before settings are applied, preserving source
                data (e.g. ``sessionWithCalibration``) needed for processing.
            status_callback: Optional callable invoked at each step with a
                status value. Receives one of:
                ``"creating_session"``,
                :class:`ImportStatusCreatedSession`,
                :class:`ImportStatusUploading`,
                or ``"processing"``.

        Returns:
            The :class:`Session` containing all imported activities.

        Raises:
            AuthenticationError: If the API key is invalid or expired.
            NetworkError: On connection failure or timeout.
            ModelHealthError: On server error, invalid JSON or processing
                failure.

        Example:

            ```python
            import json

            activities_json = json.dumps([{...}, {...}])  # list of activity dicts

            def on_status(status):
                if isinstance(status, ImportStatusUploading):
                    print(f"[{status.trial}] Uploading {status.uploaded}/{status.total}")
                else:
                    print(status)

            session = service.import_session(
                activities_json,
                subject,
                status_callback=on_status,
            )
            ```
        """
        raw_callback = None
        if status_callback is not None:
            def raw_callback(raw):
                status_callback(_to_import_status(raw))

        return self._svc.import_session(
            activities_json,
            subject,
            session_config,
            session_meta_json,
            raw_callback,
        )

    def archive_data(self, archive: Archive) -> bytes:
        """Downloads the prepared session archive as a ZIP file.

        Call this after :meth:`archive_status` returns
        ``ArchiveStatus.ready``.

        Args:
            archive: The :class:`Archive` task returned by
                :meth:`prepare_archive`.

        Returns:
            Raw ZIP bytes. Write directly to a ``.zip`` file.

        Raises:
            AuthenticationError: If the API key is invalid or expired.
            NetworkError: On connection failure or timeout.
            ModelHealthError: If the archive is not ready or the download
                fails.

        Example:

            ```python
            data = service.archive_data(archive)
            with open("session.zip", "wb") as f:
                f.write(data)
            ```
        """
        return bytes(self._svc.archive_data(archive))


__all__ = [
    "ModelHealthService",
    # Exceptions
    "ModelHealthError",
    "AuthenticationError",
    "NotFoundError",
    "NetworkError",
    # Entity types
    "Session",
    "Activity",
    "ActivityResult",
    "Video",
    "Subject",
    "SubjectParameters",
    "ActivityTag",
    "MotionData",
    "AnalysisData",
    "Analysis",
    "Archive",
    # Enum types
    "MotionDataType",
    "AnalysisDataType",
    "VideoVersion",
    "ActivitySort",
    "ActivityType",
    "ActivityConfig",
    "CheckerboardPlacement",
    # Status types
    "ActivityStatus",
    "ActivityStatusUploading",
    "ActivityStatusAnalyzing",
    "AnalysisStatus",
    "ArchiveStatus",
    "CalibrationStatus",
    "CalibrationStatusUploading",
    "CalibrationStatusProcessing",
    # Checkerboard
    "CheckerboardDetails",
    # Session configuration
    "SessionConfig",
    "SessionFramerate",
    "SessionOpenSimModel",
    "SessionScalingSetup",
    "SessionCoreEngine",
    "SessionDataSharing",
    "FilterFrequencyDefault",
    "FilterFrequencyHz",
    # Import status types
    "ImportStatusCreatedSession",
    "ImportStatusUploading",
]
