"""Native extension module for the Model Health SDK (Rust/PyO3 backend)."""

from __future__ import annotations

from typing import Literal

# ---------------------------------------------------------------------------
# String literal types
# ---------------------------------------------------------------------------

ActivitySort = Literal["updated_at"]
"""Sort order for activity lists.

Attributes:
    updated_at: Sort by most recently updated, descending.
"""


VideoVersion = Literal["raw", "synced"]
"""The processing version of the video to retrieve from an activity.

Attributes:
    raw: The original, unprocessed video as captured or uploaded.
        Raw videos represent the source material before any synchronization
        has been applied.
    synced: Videos that have been synchronized. Synced videos have undergone
        processing and may include temporal alignment or other transformations
        applied during analysis.
"""


MotionDataType = Literal[
    "animation",
    "kinematics_mot",
    "kinematics_csv",
    "markers_trc",
    "markers_csv",
    "model",
]
"""The type of motion result data to retrieve from a processed activity,
including the desired file format.

``kinematics_mot`` and ``kinematics_csv`` are only available in dynamic
activities. ``model`` is only available in neutral activities.

Attributes:
    animation: Visualiser transform JSON used for 3-D playback. Always JSON
        format.
    kinematics_mot: Inverse-kinematics results in OpenSim ``.mot`` format.
        Only available in dynamic activities.
    kinematics_csv: Inverse-kinematics results in CSV format.
        Only available in dynamic activities.
    markers_trc: Marker trajectory data in OpenSim ``.trc`` format.
    markers_csv: Marker trajectory data in CSV format.
    model: Scaled OpenSim ``.osim`` model file. Only available in neutral
        activities.

Example:

    ```python
    # Download animation data (JSON only)
    animation = service.motion_data_for_activity(activity, [MotionDataType.animation])

    # Download kinematics in MOT format
    mot = service.motion_data_for_activity(activity, [MotionDataType.kinematics_mot])

    # Download kinematics in both MOT and CSV formats
    both = service.motion_data_for_activity(
        activity, [MotionDataType.kinematics_mot, MotionDataType.kinematics_csv]
    )
    ```
"""


AnalysisDataType = Literal["metrics", "data", "report"]
"""Type of analysis result data to download from an activity with a
completed analysis.

Attributes:
    metrics: Computed biomechanical metrics. Always JSON format.
    data: Extended analysis data. Always ZIP format.
    report: Analysis report. Always PDF format.
"""


ActivityType = Literal[
    "counter_movement_jump",
    "gait",
    "treadmill_gait",
    "treadmill_running",
    "overground_running",
    "sit_to_stand",
    "squats",
    "range_of_motion",
    "drop_jump",
    "hop",
    "change_of_direction",
    "cut",
]
"""Analysis algorithm to run on a processed activity.

Analysis can only be performed on activities that have reached ``ready``
status.

Attributes:
    counter_movement_jump: Counter Movement Jump.
    gait: Overground Walking.
    treadmill_gait: Treadmill Walking.
    treadmill_running: Treadmill Running.
    overground_running: Overground Running.
    sit_to_stand: Sit-to-Stand Transfer.
    squats: Squat Exercise.
    range_of_motion: Range of Motion (ROM).
    drop_jump: Drop Vertical Jump.
    hop: Hop Test.
    change_of_direction: 5-0-5 Test.
    cut: Cutting Maneuver.
"""


Gender = Literal["woman", "man", "transgender", "non_binary", "no_response"]
"""Gender identity of a subject."""


Sex = Literal["woman", "man", "intersex", "not_listed", "no_response"]
"""Sex assigned at birth of a subject."""


CheckerboardPlacement = Literal["perpendicular", "parallel"]
"""Orientation of the calibration checkerboard relative to the ground.

Attributes:
    perpendicular: Checkerboard upright (vertical), so its plane is
        perpendicular to the ground.
    parallel: Checkerboard flat on the floor, so its plane is parallel
        to the ground.
"""


# ---------------------------------------------------------------------------
# Entity types
# ---------------------------------------------------------------------------


class CheckerboardDetails:
    """Configuration for a calibration checkerboard pattern.

    Note:
        ``rows`` and ``columns`` refer to internal corners, not squares.
        For a standard 5×6 checkerboard, use ``rows=4`` and ``columns=5``.
        ``square_size`` must be measured precisely in millimeters for
        accurate calibration.

    Example:

        ```python
        from modelhealth import CheckerboardDetails, CheckerboardPlacement

        details = CheckerboardDetails(
            rows=4,       # Internal corners, not squares (for 5×6 board)
            columns=5,    # Internal corners, not squares (for 5×6 board)
            square_size=35,  # Measured in millimeters
            placement=CheckerboardPlacement.perpendicular,
        )
        service.calibrate_camera(session, details, lambda s: print(s))
        ```
    """

    rows: int
    """Number of internal corner rows. For a 5×6 checkerboard, use ``4``."""
    columns: int
    """Number of internal corner columns. For a 5×6 checkerboard, use ``5``."""
    square_size: int
    """Size of each square in millimeters. Must be measured precisely."""
    placement: CheckerboardPlacement
    """Checkerboard orientation relative to the ground."""

    def __init__(
        self,
        rows: int,
        columns: int,
        square_size: int,
        placement: CheckerboardPlacement,
    ) -> None: ...

class Video:
    """A recorded video file from an activity.

    Videos are automatically uploaded to the cloud during recording.
    Use ``video`` as the URL for the full video.
    """

    id: str
    activity: str
    video: str | None
    video_thumb: str | None


class ActivityResult:
    """A processed result file associated with an activity."""

    id: int
    activity: str
    tag: str | None
    media: str | None


class Activity:
    """A movement recording trial with associated videos and results.

    Activities represent individual recording trials and contain references
    to captured videos and results.

    Example:

        ```python
        activities = service.activity_list(session)
        for activity in activities:
            print(f"{activity.name or activity.id}: {activity.status}")
        ```
    """

    id: str
    session: str
    name: str | None
    status: str
    videos: list[Video]
    results: list[ActivityResult]
    activity_type: ActivityType | None


class Session:
    """A parent container for a movement capture workflow.

    Sessions link related entities such as activities and subjects, and
    provide the context used by subsequent operations.

    Create a session with :meth:`ModelHealthService.create_session` before
    performing subsequent operations like camera calibration.

    When connecting or re-connecting to a session, use ``qrcode`` to
    retrieve the QR code image URL for pairing cameras.
    """

    id: str
    name: str
    session_name: str
    public: bool
    user: int
    subject: int | None
    activities_count: int
    qrcode: str | None
    activities: list[Activity]


class Subject:
    """An individual being monitored or assessed."""

    id: int
    name: str
    weight: float | None
    """Weight in kilograms."""
    height: float | None
    """Height in centimetres."""
    birth_year: int | None
    """Year of birth."""
    age: int | None
    """Age in years."""
    gender: Gender
    sex_at_birth: Sex
    characteristics: str
    """Freeform text describing relevant characteristics or medical conditions."""


class SubjectParameters:
    """Parameters for creating a new subject.

    ``name``, ``weight`` and ``height`` are required. All other fields are
    optional and default to ``"no_response"`` or empty values.

    Example:

        ```python
        from modelhealth import SubjectParameters

        params = SubjectParameters(
            name="Anonymous",
            weight=70.0,
            height=175.0,
            birth_year=1990,
        )
        subject = service.create_subject(params)
        ```
    """

    name: str
    weight: float
    """Weight in kilograms."""
    height: float
    """Height in centimetres."""
    birth_year: int | None
    sex_at_birth: Sex
    gender: Gender
    characteristics: str

    def __init__(
        self,
        name: str,
        weight: float,
        height: float,
        birth_year: int | None = None,
        sex_at_birth: Sex = "no_response",
        gender: Gender = "no_response",
        characteristics: str = "",
    ) -> None: ...


class ActivityTag:
    """A tag that can be applied to activities for categorization.

    Use tags to organize and filter activities by type or condition
    (for example, ``"cmj"``, ``"squat"``, ``"baseline"``).
    """

    value: str
    """Machine-readable tag identifier."""
    label: str
    """Human-readable display label."""


class MotionData:
    """Motion data downloaded from a processed activity.

    Use ``type`` to determine how to parse ``data``.

    Example:

        ```python
        from modelhealth import MotionDataType

        results = service.motion_data_for_activity(activity, [MotionDataType.kinematics_csv])
        for r in results:
            with open(f"{r.type}.csv", "wb") as f:
                f.write(r.data)
        ```
    """

    type: MotionDataType
    """The type of result data and its implicit file format."""
    data: bytes
    """Raw file bytes. Parse according to the format implied by ``type``."""


class AnalysisData:
    """Analysis result data downloaded from an activity with a completed analysis.

    Use ``type`` to determine how to parse ``data``.

    Example:

        ```python
        import json
        from modelhealth import AnalysisDataType

        results = service.analysis_data_for_activity(activity, [AnalysisDataType.metrics])
        for r in results:
            if r.type == "metrics":
                metrics = json.loads(r.data)
        ```
    """

    type: AnalysisDataType
    """The type of analysis result and its implicit file format."""
    data: bytes
    """Raw file bytes. Parse according to the format implied by ``type``."""


class Analysis:
    """An active analysis task returned by :meth:`ModelHealthService.start_analysis`.

    Pass to :meth:`ModelHealthService.analysis_status` to poll for completion.
    """

    id: str
    """Unique task identifier."""


class Archive:
    """An active archive preparation task returned by :meth:`ModelHealthService.prepare_archive`.

    Pass to :meth:`ModelHealthService.archive_status` to poll for readiness,
    then to :meth:`ModelHealthService.archive_data` to download the ZIP file.
    """

    id: str
    """Opaque identifier for the archive preparation task."""


# ---------------------------------------------------------------------------
# Exception hierarchy
# ---------------------------------------------------------------------------

class ModelHealthError(RuntimeError):
    """Base exception for all Model Health SDK errors."""

class AuthenticationError(ModelHealthError):
    """Raised when the API key is missing, invalid or expired (HTTP 401/403)."""

class NotFoundError(ModelHealthError):
    """Raised when a requested resource does not exist (HTTP 404)."""

class NetworkError(ModelHealthError):
    """Raised on connection failure, timeout or DNS error."""

# ---------------------------------------------------------------------------
# Activity status types (raw native variants — see modelhealth.ActivityStatus)
# ---------------------------------------------------------------------------

class ActivityStatusUploading:
    """Internal: videos are still being uploaded. Use ``modelhealth.ActivityStatusUploading`` instead."""

    uploaded: int
    """Number of videos successfully uploaded so far."""
    total: int
    """Total number of videos expected from all cameras."""


class ActivityStatusProcessing:
    """Internal: activity is being processed. Use ``modelhealth.ActivityStatus.processing`` instead."""

class ActivityStatusReady:
    """Internal: activity is ready for analysis. Use ``modelhealth.ActivityStatus.ready`` instead."""

class ActivityStatusAnalyzing:
    """Internal: analysis is in progress. Use ``modelhealth.ActivityStatusAnalyzing`` instead."""

    task: Analysis

class ActivityStatusFailed:
    """Internal: processing failed. Use ``modelhealth.ActivityStatus.failed`` instead."""

# ---------------------------------------------------------------------------
# Analysis status types (raw native variants — see modelhealth.AnalysisStatus)
# ---------------------------------------------------------------------------

class AnalysisStatusProcessing:
    """Internal: analysis is in progress. Use ``modelhealth.AnalysisStatus.processing`` instead."""

class AnalysisStatusCompleted:
    """Internal: analysis completed successfully. Use ``modelhealth.AnalysisStatus.completed`` instead."""

class AnalysisStatusFailed:
    """Internal: analysis failed. Use ``modelhealth.AnalysisStatus.failed`` instead."""

# ---------------------------------------------------------------------------
# Archive status types (raw native variants — see modelhealth.ArchiveStatus)
# ---------------------------------------------------------------------------

class ArchiveStatusProcessing:
    """Internal: archive is being prepared. Use ``modelhealth.ArchiveStatus.processing`` instead."""

class ArchiveStatusReady:
    """Internal: archive is ready to download. Use ``modelhealth.ArchiveStatus.ready`` instead."""

class ArchiveStatusFailed:
    """Internal: archive preparation failed. Use ``modelhealth.ArchiveStatus.failed`` instead."""

# ---------------------------------------------------------------------------
# Import status types (raw native variants — see modelhealth.ImportStatusUploading)
# ---------------------------------------------------------------------------

class ImportStatusCreatingSession:
    """Internal: creating a new session. Use ``"creating_session"`` string instead."""

class ImportStatusCreatedSession:
    """Internal: session created. Use ``modelhealth.ImportStatusCreatedSession`` instead."""

    session_id: str
    """ID of the newly created session."""

class ImportStatusUploadingVideo:
    """Internal: uploading a video. Use ``modelhealth.ImportStatusUploading`` instead."""

    trial: str
    """Name of the trial whose video is being uploaded."""
    uploaded: int
    """Number of videos successfully uploaded so far."""
    total: int
    """Total number of videos to upload."""

class ImportStatusProcessing:
    """Internal: server is processing the trial. Use ``"processing"`` string instead."""

# ---------------------------------------------------------------------------
# Calibration status types (raw native variants — see modelhealth.CalibrationStatus)
# ---------------------------------------------------------------------------

class CalibrationStatusRecording:
    """Internal: cameras are actively recording. Use ``modelhealth.CalibrationStatus.recording`` instead."""

class CalibrationStatusUploading:
    """Internal: videos are being uploaded. Use ``modelhealth.CalibrationStatusUploading`` instead."""

    uploaded: int
    """Number of videos successfully uploaded so far."""
    total: int
    """Total number of videos expected from all cameras."""

class CalibrationStatusProcessing:
    """Internal: server is processing videos. Use ``modelhealth.CalibrationStatusProcessing`` instead."""

    percent: int | None
    """Processing completion percentage (0–100), or ``None`` if unavailable."""

class CalibrationStatusDone:
    """Internal: calibration completed. Use ``modelhealth.CalibrationStatus.done`` instead."""

# Filter frequency types

class FilterFrequencyDefault:
    """Let the server choose the optimal filter frequency (default).

    The server applies a low-pass Butterworth filter to 2D video keypoints
    at 20 Hz by default.
    """
    def __init__(self) -> None: ...

class FilterFrequencyHz:
    """Use a specific low-pass filter frequency in Hz.

    The specified frequency applies to all motion trials in the session.
    Per the Nyquist theorem the value must be less than half the session
    framerate; if it exceeds that the server clamps it automatically.
    """
    value: int
    def __init__(self, value: int) -> None: ...

# ---------------------------------------------------------------------------
# Native service (internal — use modelhealth.ModelHealthService instead)
# ---------------------------------------------------------------------------

class ModelHealthService:
    """Internal PyO3 service. The public API is modelhealth.ModelHealthService."""

    def __init__(self, api_key: str) -> None: ...
    def session_list(self) -> list[Session]: ...
    def get_session(self, session_id: str) -> Session: ...
    def create_session(self) -> Session: ...
    def configure_session(self, session: Session, framerate: str, opensim_model: str, scaling_setup: str, core_engine: str, filter_frequency: object, data_sharing: str) -> None: ...
    def subject_list(self) -> list[Subject]: ...
    def create_subject(self, parameters: SubjectParameters) -> Subject: ...
    def activities_for_subject(self, subject_id: int, start_index: int, count: int, sort: ActivitySort) -> list[Activity]: ...
    def fetch_activity(self, activity_id: str) -> Activity: ...
    def update_activity(self, activity: Activity) -> Activity: ...
    def delete_activity(self, activity: Activity) -> None: ...
    def activity_tags(self) -> list[ActivityTag]: ...
    def activity_list(self, session_id: str) -> list[Activity]: ...
    def videos_for_activity(self, activity: Activity, version: VideoVersion) -> list[bytes]: ...
    def motion_data_for_activity(self, activity: Activity, data_types: list[MotionDataType]) -> list[MotionData]: ...
    def analysis_data_for_activity(self, activity: Activity, data_types: list[AnalysisDataType]) -> list[AnalysisData]: ...
    def activity_status(self, activity: Activity) -> ActivityStatusUploading | ActivityStatusProcessing | ActivityStatusReady | ActivityStatusAnalyzing | ActivityStatusFailed: ...
    def start_analysis(self, activity_type: ActivityType, activity: Activity, session: Session) -> Analysis: ...
    def analysis_status(self, task: Analysis) -> AnalysisStatusProcessing | AnalysisStatusCompleted | AnalysisStatusFailed: ...
    def prepare_archive(self, session: Session, with_videos: bool) -> Archive: ...
    def archive_status(self, archive: Archive) -> ArchiveStatusProcessing | ArchiveStatusReady | ArchiveStatusFailed: ...
    def archive_data(self, archive: Archive) -> bytes: ...
    def start_recording(self, name: str, session: Session, activity_type: ActivityType | None = None) -> Activity: ...
    def stop_recording(self, session: Session) -> None: ...
    def calibrate_camera(self, session: Session, checkerboard: CheckerboardDetails, status_callback: object) -> None: ...
    def calibrate_subject(self, subject: Subject, session: Session, status_callback: object) -> None: ...
    def import_session(self, activities_json: str, subject: Subject, session_config: object | None = None, session_meta_json: str | None = None, status_callback: object | None = None) -> Session: ...
